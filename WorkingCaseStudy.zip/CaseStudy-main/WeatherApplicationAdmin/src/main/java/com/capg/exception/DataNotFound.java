package com.capg.exception;


public class DataNotFound extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DataNotFound() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DataNotFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
