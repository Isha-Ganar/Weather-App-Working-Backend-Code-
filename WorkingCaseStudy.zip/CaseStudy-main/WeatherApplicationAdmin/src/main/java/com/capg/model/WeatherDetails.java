package com.capg.model;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


//when we are using MongoRepository @Document annotation is used
@Document(collection = "DetailsOfWeather")
public class WeatherDetails
{
	// Parameter Variables for Weather
	@Id
	private int id;

	private String location;

	private Double temperature, atmosphericPressure, humidity, precipitation, solarRadiation, wind;

	
	// All Getters And Setters
	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getLocation() {
		return location;
	}


	public void setLocation(String location) {
		this.location = location;
	}


	public Double getTemperature() {
		return temperature;
	}


	public void setTemperature(Double temperature) {
		this.temperature = temperature;
	}


	public Double getAtmosphericPressure() {
		return atmosphericPressure;
	}


	public void setAtmosphericPressure(Double atmosphericPressure) {
		this.atmosphericPressure = atmosphericPressure;
	}


	public Double getHumidity() {
		return humidity;
	}


	public void setHumidity(Double humidity) {
		this.humidity = humidity;
	}


	public Double getPrecipitation() {
		return precipitation;
	}


	public void setPrecipitation(Double precipitation) {
		this.precipitation = precipitation;
	}


	public Double getSolarRadiation() {
		return solarRadiation;
	}


	public void setSolarRadiation(Double solarRadiation) {
		this.solarRadiation = solarRadiation;
	}


	public Double getWind() {
		return wind;
	}


	public void setWind(Double wind) {
		this.wind = wind;
	}

	// Parameterized Constructor
	
	public WeatherDetails(int id, String location, Double temperature, Double atmosphericPressure, Double humidity,
			Double precipitation, Double solarRadiation, Double wind)
	{
		super();
		this.id = id;
		this.location = location;
		this.temperature = temperature;
		this.atmosphericPressure = atmosphericPressure;
		this.humidity = humidity;
		this.precipitation = precipitation;
		this.solarRadiation = solarRadiation;
		this.wind = wind;
	}


	// Default Constructor 
	public WeatherDetails() {
		super();
	}


	// toString Method
	@Override
	public String toString() {
		return "WeatherDetails [id=" + id + ", location=" + location + ", temperature=" + temperature
				+ ", atmosphericPressure=" + atmosphericPressure + ", humidity=" + humidity + ", precipitation="
				+ precipitation + ", solarRadiation=" + solarRadiation + ", wind=" + wind + "]";
	}

	

	

}
