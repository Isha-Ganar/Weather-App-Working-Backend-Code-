package com.cg.exception;

public class Invalid_CredentialsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Invalid_CredentialsException() {
		super();
	}

	public Invalid_CredentialsException(String message) {
		super(message);
	}

}
